
This TangentHub executable logs debug information to standard-out.

Be sure to disable or uninstall any other Tangent Hub software before attempting to use this debug version.

If you have installed the Tangent Hub software you can temporarily disable it with the command:

sudo /sbin/service tangenthub stop

To resume using the installed version after quitting the debug executable, restart the service with the following command or simply reboot the machine.

sudo /sbin/service tangenthub start

Please ensure that the local copy of the application has executable permissions set.


Run the standard make command to build the MockApplication executable (you must have an installed build environment).

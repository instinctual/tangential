
You must run the MockApplication from a terminal window in the same directory as the 'sys' sub-directory.

Run the app with the '-unmanaged' command line argument to drive the hub in unmanaged mode.

The controls.xml and xxx-map.xml files define some very basic application capabilities and simple panel 
mappings. These are only intended to illustrate the file layouts and syntax.

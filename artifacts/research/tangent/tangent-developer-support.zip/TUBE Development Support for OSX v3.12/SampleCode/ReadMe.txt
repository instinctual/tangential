
To be able to run the MockApplication from within Xcode, you must make sure that the executable working
directory is set to the project base directory so it can find the test files in the example system folder.

Depending on your version of Xcode:

In the project's Groups & Files area, go to Executables->MockApplication and right click to Get Info. In 
the General tab make sure the working directory is set to the Project directory.

or

Select the Product > Scheme > Edit Scheme... menu option and in the Run (Debug) scheme set the Working 
Directory folder to the Project directory.

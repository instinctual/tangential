
This TangentHub executable logs debug information to standard-out.

Be sure to disable or uninstall any other Tangent Hub software before attempting to use this debug version.

If you have installed the Tangent Hub software you can temporarily disable it with the command:

TaskRunner.exe -halt

To resume using the installed version after quitting the debug executable, restart the service with the following command or simply reboot the machine.

TaskRunner.exe

(The TaskRunner utility can be found in the installed Tangent Hub program folder.)

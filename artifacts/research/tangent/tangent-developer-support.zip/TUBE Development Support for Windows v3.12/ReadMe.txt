
The three folders contain:

MockApplication:
  A sample application that will connect to the Hub.
  This can be run from a terminal window in the same directory as the 'sys' directory
  The files in the 'sys' directory will be used to define the capabilities of the application and panels.
  If the application is run with the '-unmanaged' argument the hub will be driven in unmanaged mode which 
  does not use the data in the 'sys' directory.
  
SampleCode:
  The source code for the mock application.
  The 'sys' folder is duplicated within this folder for ease of use.

TangentHub-Debug:
  This TangentHub executable logs debug information to standard-out.
  Be sure to disable or uninstall any other Tangent Hub software before attempting to use this debug version.

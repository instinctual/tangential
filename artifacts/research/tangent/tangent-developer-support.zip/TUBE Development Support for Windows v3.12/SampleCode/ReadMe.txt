
The MockApplication solution can be loaded and built by Microsoft Visual C++ 2010 Express or equivalent.
